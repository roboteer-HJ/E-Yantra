
import task_1b_cardinal


if __name__ == "__main__":
    task_1b_cardinal.main()

